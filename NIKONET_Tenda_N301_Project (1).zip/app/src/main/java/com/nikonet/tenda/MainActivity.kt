package com.nikonet.tenda

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL

class MainActivity : AppCompatActivity() {
    private lateinit var ip: EditText
    private lateinit var user: EditText
    private lateinit var pass: EditText
    private lateinit var output: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 28, 32, 24)
        }

        val title = TextView(this).apply {
            text = "NIKONET"
            textSize = 30f
            setTextColor(0xFF1565C0.toInt())
        }
        val subtitle = TextView(this).apply {
            text = "Kontrol Router Tenda N301"
            textSize = 16f
        }

        ip = EditText(this).apply {
            hint = "IP Router (contoh 192.168.0.1)"
            setText("192.168.0.1")
            inputType = 1
        }
        user = EditText(this).apply {
            hint = "Username admin"
            setText("admin")
        }
        pass = EditText(this).apply {
            hint = "Password admin"
            inputType = 129
        }

        val connect = Button(this).apply {
            text = "CEK KONEKSI ROUTER"
            setOnClickListener { checkRouter() }
        }

        val reboot = Button(this).apply {
            text = "BUKA HALAMAN ADMIN"
            setOnClickListener { openAdmin() }
        }

        output = TextView(this).apply {
            text = "Masukkan IP router lalu cek koneksi."
            textSize = 15f
            setPadding(0, 18, 0, 0)
        }

        root.addView(title)
        root.addView(subtitle)
        root.addView(ip)
        root.addView(user)
        root.addView(pass)
        root.addView(connect)
        root.addView(reboot)
        root.addView(output)
        setContentView(root)
    }

    private fun checkRouter() {
        val host = ip.text.toString().trim()
        output.text = "Menghubungkan ke $host..."
        lifecycleScope.launch {
            val result = withContext(Dispatchers.IO) {
                try {
                    val url = URL("http://$host/")
                    val c = url.openConnection() as HttpURLConnection
                    c.connectTimeout = 4000
                    c.readTimeout = 4000
                    c.requestMethod = "GET"
                    val code = c.responseCode
                    c.disconnect()
                    "Router merespons. HTTP $code\nIP: $host"
                } catch (e: Exception) {
                    "Gagal terhubung ke router.\nPastikan HP terhubung ke WiFi Tenda dan IP benar.\n\n${e.message}"
                }
            }
            output.text = result
        }
    }

    private fun openAdmin() {
        val host = ip.text.toString().trim()
        lifecycleScope.launch(Dispatchers.Main) {
            val intent = android.content.Intent(
                android.content.Intent.ACTION_VIEW,
                android.net.Uri.parse("http://$host/")
            )
            startActivity(intent)
        }
    }
}
