# NIKONET — Tenda N301

Aplikasi Android starter untuk mengakses router Tenda N301 melalui jaringan lokal.

## Build APK

1. Buka folder proyek ini di Android Studio.
2. Tunggu Gradle Sync selesai.
3. Pilih **Build > Build APK(s)**.
4. APK debug biasanya berada di:
   `app/build/outputs/apk/debug/app-debug.apk`

## Cara menggunakan

1. Sambungkan HP ke WiFi Tenda N301.
2. Jalankan NIKONET.
3. Masukkan IP router, biasanya `192.168.0.1` atau sesuai konfigurasi router.
4. Tekan **CEK KONEKSI ROUTER**.
5. Tombol **BUKA HALAMAN ADMIN** membuka antarmuka administrasi router.

## Catatan penting

Firmware Tenda N301 memiliki variasi antarmuka/endpoint. Source ini sengaja tidak meng-hardcode endpoint login, perubahan SSID/password, blokir perangkat, atau reboot karena endpoint tersebut harus disesuaikan dengan firmware router yang digunakan.

Untuk membuat kontrol native penuh, identifikasi endpoint/API firmware N301 yang dipakai, lalu implementasikan di `MainActivity.kt` atau pisahkan ke `TendaApi.kt`.
